import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nutricioneditarplato',
  templateUrl: './nutricioneditarplato.page.html',
  styleUrls: ['./nutricioneditarplato.page.scss'],
})
export class NutricioneditarplatoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
