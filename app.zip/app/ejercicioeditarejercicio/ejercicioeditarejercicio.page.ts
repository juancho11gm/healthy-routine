import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejercicioeditarejercicio',
  templateUrl: './ejercicioeditarejercicio.page.html',
  styleUrls: ['./ejercicioeditarejercicio.page.scss'],
})
export class EjercicioeditarejercicioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
