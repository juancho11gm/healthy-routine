export interface Peso{
    pes:number;
    fecha:String;
    imc:number;
}