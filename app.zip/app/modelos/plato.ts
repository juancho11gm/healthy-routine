export interface Plato{
    nombre:string;
    imagen:string;
    descripcion:string;
    key:string;
    duracion:string;
    calorias:string;
    ingredientes :string [];
    pasos :string [];
    tipo:string;
}