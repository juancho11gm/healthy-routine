
export interface Ejercicio{
    nombre:string;
    imagen:string;
    descripcion:string;
    visible:boolean;
    key:string;
    series:number;
    repeticiones:number;
    tiempodescanso:number;
}