export interface Caloria{
    pes:number;
    fecha:String;
}