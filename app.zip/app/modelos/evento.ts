export interface Evento{
    title: String,
    desc: String,
    startTime:String,
    endTime: String,
    allDay: boolean,
    tipo:string,
}
