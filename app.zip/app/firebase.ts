const config = {
  apiKey: "AIzaSyDidIfGpCRuxDUhenb1HgILYNli3DffJt0",
  authDomain: "healthy-routine.firebaseapp.com",
  databaseURL: "https://healthy-routine.firebaseio.com",
  projectId: "healthy-routine",
  storageBucket: "healthy-routine.appspot.com",
  messagingSenderId: "277292940640"
  };
export default config